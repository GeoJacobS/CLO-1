import csv
import os
from getpass import getpass
import sys




def login():
    while True:
        l_c=input('Are you an Existing or New user? Press E/N: ')
        if l_c in 'Nn':
            u_n=input('Enter desired username: ')
            pw1 = getpass('Create password: ')
            pw2 = getpass('Confirm password: ')
            if pw1==pw2:
                usr_dat=[u_n,pw2]
                csvw.writerow(usr_dat)
                print('Account sucessfully created\n')
                break
            elif pw1!=pw2:
                print('Passwords do not match. Try again')
        elif l_c in 'Ee':
            usrname=input('Enter username: ')
            pw = getpass('Enter password: ')
            k=0
            for i in csvr:
                if i[0]==usrname and i[1]==pw:
                    k=1
                    print('Login Sucessful!')
            break
            if k==0:
                print('Invalid Login details. Retry..')
                
        else:
            print('Invalid Input')
                    

#def song_details():
    
                
def pwd_change(usr):
    data=list(csvr)
    k=0
    for i in data:
        
        if i[0]==usr:
            i[1]= str(getpass('Enter new password: '))
            ud.seek(0)
            csvw.writerows(data)
            k=1
            print('Password Changed')
    if k==0:
        print('User not found')
            
def playlist():
    playlist_name=input('Enter the name for your playlist: ')
    os.mkdir(playlist_name)
    import Viber
    
    



print('Welcome to Vibe.exe! Your very own music player\n')


while True:

    with open('usr_dat.csv','r+',newline='') as ud:
        csvw=csv.writer(ud)
        csvr=csv.reader(ud)                   
    
        i_n=input('Press 1 to login or Switch users\nPress 2 to Change password\nPress 3 to Create a playlist and play music\nPress 4 to Exit\nEnter choice: ')
        if i_n in '1':
            login() 
        elif i_n in '2':
            usr=input("Enter your username: ")
            pwd_change(usr)
        elif i_n in '3':
            playlist()
        elif i_n in '4':
            print('Thanks for using Vibe.exe\nCome back again!')
            break
        else:
            print('Invalid Input..')
